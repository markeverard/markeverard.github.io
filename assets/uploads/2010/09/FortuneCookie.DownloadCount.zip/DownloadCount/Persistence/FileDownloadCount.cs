using EPiServer.Data.Dynamic;

namespace DownloadCount.Persistence
{
	public class FileDownloadCount
	{
		[EPiServerDataIndex]
        public string FilePath { get; set; }
        public int Count { get; set; } 
    }
}