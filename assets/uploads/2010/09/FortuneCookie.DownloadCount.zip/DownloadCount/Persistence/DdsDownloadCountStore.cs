using System.Web;
using EPiServer.Data.Dynamic;
using System.Linq;

namespace DownloadCount.Persistence
{
	public class DdsDownloadCountStore : IDownloadCountStore
	{
	    protected DynamicDataStore GetDynamicDataStore()
		{
			return DynamicDataStoreFactory.Instance.GetStore(typeof(FileDownloadCount)) ??
					DynamicDataStoreFactory.Instance.CreateStore(typeof(FileDownloadCount));
		}

		public void UpdateDownloadCount(string path)
		{
		    path = UrlDecodePath(path);
		    using(var store = GetDynamicDataStore())
		    {
                var fileCount = store.Find<FileDownloadCount>("FilePath", path).FirstOrDefault() 
                                                        ?? FileDownloadCountFactory.Create(path);
			    fileCount.Count++;
			    store.Save(fileCount);
            }
		}

	    private static string UrlDecodePath(string path)
	    {
	        return HttpUtility.UrlDecode(path);
	    }

	    public int GetDownloadCount(string path)
	    {
	        path = UrlDecodePath(path);
            using (var store = GetDynamicDataStore())
            {
                var fileCount = store.Find<FileDownloadCount>("FilePath", path).FirstOrDefault();
                return fileCount == null ? 0 : fileCount.Count;
			}
		}
	}
}