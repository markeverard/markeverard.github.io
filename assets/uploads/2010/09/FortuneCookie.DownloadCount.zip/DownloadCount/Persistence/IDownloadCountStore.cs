namespace DownloadCount.Persistence
{
	public interface IDownloadCountStore
	{
		void UpdateDownloadCount(string path);
		int GetDownloadCount(string path);
	}

}