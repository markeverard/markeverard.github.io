namespace DownloadCount.Persistence
{
    public class FileDownloadCountFactory
    {
        public static FileDownloadCount Create(string path)
        {
            return new FileDownloadCount() { Count = 0, FilePath = path };
        }
    }
}