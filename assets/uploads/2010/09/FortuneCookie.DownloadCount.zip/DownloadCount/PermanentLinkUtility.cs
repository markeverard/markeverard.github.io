using System.Web.Hosting;
using EPiServer.Web.Hosting;

namespace DownloadCount
{
    public static class PermanentLinkUtility
    {
        public static string MapRequestPathToPermanentLink(string filePath)
        {
            var file = HostingEnvironment.VirtualPathProvider.GetFile(filePath) as UnifiedFile;
            if (file == null) return filePath;
            return string.IsNullOrEmpty(file.PermanentLinkVirtualPath)
                        ? filePath
                        : file.PermanentLinkVirtualPath;
        }
    }
}