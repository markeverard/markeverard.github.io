﻿using System.Web;
using DownloadCount.Persistence;

namespace DownloadCount
{
    public class DownloadCountHttpHandler : EPiServer.Web.StaticFileHandler
    {
        public DownloadCountHttpHandler()
        {
            ViewCountStore = new DdsDownloadCountStore();
        }

        protected IDownloadCountStore ViewCountStore { get; set; }

        protected override bool ProcessRequestInternal(HttpContext context)
        {
            var permanentPath = PermanentLinkUtility.MapRequestPathToPermanentLink(context.Request.FilePath);
            ViewCountStore.UpdateDownloadCount(permanentPath);
            return base.ProcessRequestInternal(context);
        }

        public override bool IsReusable
        {
            get { return true; }
        }
    }
}
